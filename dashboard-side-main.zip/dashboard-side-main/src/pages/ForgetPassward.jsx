import React from 'react';

const ForgetPassward = () => {
    return (
        <div>
            <h1>Forget Passward</h1>
        </div>
    );
};

export default ForgetPassward;